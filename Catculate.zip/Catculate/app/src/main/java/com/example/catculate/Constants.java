package com.example.catculate;

public class Constants {

  public static int SYMBOLIC_ADD = 0;
  public static int SYMBOLIC_MINUS = 1;

  public static int STATE_COMPLETED = 0;
  public static int STATE_INCOMPLETED = 1;

}
